package lesson6.exercise_3;

@FunctionalInterface
public interface ValGetter {
	int getValue();
}
