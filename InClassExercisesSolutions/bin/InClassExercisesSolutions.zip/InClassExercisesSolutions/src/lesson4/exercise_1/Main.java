package lesson4.exercise_1;

public class Main {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Student st1, st2, st3;
		Graduate st4;
		st1 = new Student();
		st2 = new Undergraduate();
		st3 = new Graduate();
		//st4 = new Student();  compiler error


	}

}
