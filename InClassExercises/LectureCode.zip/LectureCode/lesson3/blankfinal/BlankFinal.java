package lesson3.blankfinal;

public class BlankFinal {
	static final int blankFinal = 3;
	
	//cannot do this because it's static
	//static final int another;
	
	public BlankFinal() {
		//blankFinal = 3;
	}

	void test() {
		//blankFinal = 5;
	}
}
