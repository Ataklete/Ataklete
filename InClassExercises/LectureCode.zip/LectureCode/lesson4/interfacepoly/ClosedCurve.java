package lesson4.interfacepoly;

public interface ClosedCurve {
	double computeArea();

}
