package lesson4.polymorph.employee;

public class Secretary extends Employee {

	public Secretary(String name, double salary, int year, int month, int day) {
		super(name, salary, year, month, day);
	}

}
