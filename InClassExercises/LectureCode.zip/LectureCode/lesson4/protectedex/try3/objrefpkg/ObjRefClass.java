package lesson4.protectedex.try3.objrefpkg;

import lesson4.protectedex.try3.superpkg.SuperClass;

public class ObjRefClass extends SuperClass {
	
}
