package lesson4.protectedex.try2.superpkg;

public class SuperClass {
	protected String getVal() {
		return "val";
	}
}
