package lesson4.comparable;

public class PersonData {
	public static Person[] personData 
	  = {new Person("Joe"), new Person("Bill"), 
			  new Person("Sue"), new Person("Alice")};
	
}
