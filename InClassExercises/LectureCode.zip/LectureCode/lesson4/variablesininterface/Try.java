package lesson4.variablesininterface;

public class Try implements Animal {

	public static void main(String[] args) {
		System.out.println(x);
		//x = 2; compiler error

	}
	
	
}
