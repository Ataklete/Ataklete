package lesson4.reflect;

abstract public class ClosedCurve {
	abstract double computeArea();

}
