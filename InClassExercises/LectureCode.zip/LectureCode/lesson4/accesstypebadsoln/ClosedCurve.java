package lesson4.accesstypebadsoln;

abstract public class ClosedCurve {
	abstract double computeArea();

}
