package lesson2.stringcompareto;

import java.util.Arrays;

public class Test1 {

	public static void main(String[] args) {
		String[] names = {"Steve", "Joe", "Alice", "Tom"};
		//sorts the array in place
		Arrays.sort(names);
		System.out.println(Arrays.toString(names));
		
		//autoboxing
		
//		Integer y = Integer.valueOf(3);
//		int x = y.intValue();
//		Integer[] arr = {2,3,4,5};
//		Integer z = 5;
//		z++;
//		System.out.println(z);
		//output: 6
		
	}

}
