package lesson12.improvedtriangle;

public class IllegalTriangleException extends Exception {

	public IllegalTriangleException(){
		super();
	}
	public IllegalTriangleException(String msg) {
		super(msg);
	}
	
	
	private static final long serialVersionUID = 3258132448972648755L;



}
