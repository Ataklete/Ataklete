package final_exam_practice_problem;

import java.util.Iterator;
import java.util.Set;
import java.util.Collection;
import java.util.HashMap;

public class Prob2_HashMap {

	HashMap <String,String> removeZ (HashMap <String,String>  map) {
		HashMap<String, String> newMap = new HashMap<String, String>();
		
		//implement
		
		return newMap;	
	}
	
	public static void main(String[] args) {
		Prob2_HashMap p1 = new Prob2_HashMap();
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("book","book");
		map.put("Zebra","Zebra");
		map.put("apple","apple");
		map.put("Total","Total");
		map.put("AtoZ","AtoZ");
		HashMap<String,String> newMap = p1.removeZ(map);
		Set<String> keys = newMap.keySet();
		Iterator it = keys.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
