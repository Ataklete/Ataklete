package prog2_5_palindrome_soln;

import java.util.Scanner;

public class Prog5 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String input="";
		while (true) {
			System.out.print("Type in a string: ");
			input = sc.nextLine();
			if (input.equals("no"))
				break;

			System.out.println("is text a Palindrome?  "+isPalindrome(input));			
			System.out.println("reverse is Palindrome? "+checkPalindrome(input));			
			System.out.println();
		}
	}
	
	static boolean isPalindrome(String s) {
		if(s == null || s.length() < 2) {
			return true;
		}
		int front = 0;
		int mid = s.length()/2;
		int back = s.length()-1;
		while (mid >= front) {
			if (s.charAt(front) != s.charAt(back))
				return false;
			front++; 
			back--;
		}
		return true;
	}
	
	// reversing then comparing
	static boolean checkPalindrome(String text){
       
        StringBuilder sb = new StringBuilder();
        for(int i = text.length() -1; i>=0 ; i--){
            sb.append(text.charAt(i));
        }
        String reversed = sb.toString();
        return text.equals(reversed);
    }

}
