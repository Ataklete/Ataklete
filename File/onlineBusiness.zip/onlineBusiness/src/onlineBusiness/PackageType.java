package onlineBusiness;

public enum PackageType {
	INDIVIDUAL,
	BUSINESS

}
