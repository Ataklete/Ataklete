package onlineBusiness;

public interface Int {
	public String Box();
	public String Bag();
	public String Wrap();

}
