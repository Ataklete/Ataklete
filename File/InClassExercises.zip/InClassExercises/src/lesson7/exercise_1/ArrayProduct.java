package lesson7.exercise_1;

import java.util.Arrays;

public class ArrayProduct {

	public ArrayProduct() {
		
	}

	double calcProduct1(int[] arrayOfNums) {
		return 0;
	}
	
	
	public static void main(String[] args) {
		int[] arrayOfNumbers = {5,2,8,1,6};
		ArrayProduct aProduct = new ArrayProduct();
		System.out.println("Product of arrays (#1) is: "+aProduct.calcProduct1(arrayOfNumbers));

	}

}
