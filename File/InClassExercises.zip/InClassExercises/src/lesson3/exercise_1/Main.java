package lesson3.exercise_1;

import java.time.LocalDate;
import java.util.Date;

public class Main {

	public static void main(String[] args) {
		
		Date date = dateFromLocalDate(LocalDate.of(1970, 1, 2));
		int numHours = -1; //implement
		//output numHours to the console

	}

	public static Date dateFromLocalDate(LocalDate localDate) {
		//implement
		return null;
	}
}
