package lesson6.exercise_3;

public interface ValGetter {
	int getValue();
}
