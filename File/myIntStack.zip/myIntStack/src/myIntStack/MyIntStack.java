package myIntStack;
import java.util.EmptyStackException;
public class MyIntStack {
	//DO NOT MODIFY the declaration or initialization of arr
	private Integer[] arr = new Integer[8];
	private Node Top;
	private int front = 0;
	
	/** Returns true if this stack has no elements */
	public boolean isEmpty() {
		//implement
		return (front==0);
		//return false;
	}
	
	/** Pushes an Integer onto the stack. Null inputs 
	 *  are ignored (if the input is null, the method
	 *  simply returns, without modifying the stack in any way.)
	 * @param 
	 */
	public void push(Integer x) {
		//implement
			arr[front] = x;
			front++;
	
	}

	/** Removes and returns the top element of the stack if
	 * the stack is not empty. If the stack is empty when
	 * pop is called, it causes a MyStackException to be thrown
	 */
	public Integer pop() throws MyStackException {
		//return 1;
		//implement
		if(isEmpty())
			throw new MyStackException("Stack is empty");
		//int x = peek();
		arr[front] = 0;
		front--;
		return front;
		
	}
	
	/** Returns, but does not remove, the top element of the stack if
	 * the stack is not empty. If the stack is empty when
	 * peek is called, it causes a MyStackException to be thrown
	 */
	public int peek() throws MyStackException {
		//return 1;
		//implement
		if(isEmpty()) {
			throw new MyStackException("Stack is empty");	
		}else {
			return arr[front];
		}
	}
	
	@Override
	public String toString() {
		return "MyIntStack [Top=" + Top + ", front=" + front + "]";
	}

	class Node {
		int data;
		Node Top;
		
		  public Node() { 
			  this.data = data;
			 // this.Top = top;
			  }
		 
		
	
	}
	public static void main(String[] args) throws MyStackException  {
		
		MyIntStack a = new MyIntStack();

		for(int i = 1; i < 8; i ++)
			a.push(i);
		for(int i = 1; i < 3; i ++) 
			a.pop();
		
		System.out.println(a.peek());
		System.out.println(a.isEmpty());
		
	}
}


