package final3;

public class Distance3D implements ThreeDDistance{

	@Override
	public double getDistance(Point p1, Point p2) {
		double x= p1.getX()-p2.getX();
		double y= p1.getY()-p2.getY();
		double z= p1.getZ()-p2.getZ();
		return Math.sqrt(Math.pow(x, 2)+Math.pow(y, 2)+Math.pow(z, 2));
		
		
	}
}
