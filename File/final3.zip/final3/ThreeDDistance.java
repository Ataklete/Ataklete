package final3;

public interface ThreeDDistance {
	public double getDistance(Point p1, Point p2);

}
