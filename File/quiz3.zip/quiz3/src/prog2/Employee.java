package prog2;

public class Employee {

}
