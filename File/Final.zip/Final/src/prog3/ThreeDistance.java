package prog3;

public interface ThreeDistance {
	public double getDistance(Point p1, Point p2);

}
