package prog3;

public class Distance3D implements ThreeDistance{

	@Override
	public double getDistance(Point p1, Point p2) {
		
		
		double x= p1.getX()-p2.getX();
		double y= p1.getY()-p2.getY();
		double z= p1.getZ()-p2.getZ();
		double x1 = Math.sqrt(Math.pow(x, 2));
		double x2 = Math.pow(y, 2);
		double x3 = Math.pow(z, 2);
		
		
		return x1+x2+x3;
		
		
	}
}
