package prog3;

public class Main {
	
	public static void main(String[] args) {
		 Point p1 =new Point(5,10,3);
		 Point p2 =new Point(12,3,5);
	Distance3D d = new Distance3D();
	
	
	System.out.println(d.getDistance(p1, p2));
	}

}
