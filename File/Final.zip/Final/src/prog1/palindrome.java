package prog1;

import java.util.Scanner;

public class palindrome {

	static boolean isPalindrome(String s) 
    { 
		if(s.length() == 0 || s.length() == 1)
            return true; 
        if(s.charAt(0) == s.charAt(s.length()-1))
       
        return isPalindrome
        		(s.substring(1, s.length()-1));

        
        return false;
       
//        int i = 0, j = str.length() - 1; 
//  
//        	        while (i < j) { 
//  
//            // If there is a mismatch 
//            if (str.charAt(i) != str.charAt(j)) 
//                return false; 
//  
//            return isPalindrome(substring(i++)) && isPalindrome(substring(j--));
//         //   i++; 
//         //   j--; 
//        } 
//  
//       
//        return true; 
    } 
  
    
    private static String substring(int i) {
		// TODO Auto-generated method stub
		return null;
	}


	public static void main(String[] args) 
    { 
        
  Scanner cs = new Scanner(System.in);
  System.out.println("Enter the word; ");
  String str = cs.nextLine();
        if (isPalindrome(str)) 
            System.out.print("Yes"); 
        else
            System.out.print("No"); 
    } 
}
