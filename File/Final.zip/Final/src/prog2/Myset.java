package prog2;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Myset {
	
    private Map<String, Integer> counts;
    public int size() {
        
        return counts.size();
    }
    public boolean contains(String x) {
        return counts.containsKey(x);
    }

    public void add(String x) {
        
        if (contains(x)){
            int x1=counts.get(x);
            int y1=x1+1;
            counts.put(x,y1);
        } else {
            counts.put(x,1);
        }
    }

 
    public boolean remove(String x) {
        if (contains(x)){
            if(counts.get(x)==1){
                counts.remove(x);
            } else {
                int x1=counts.get(x);
                int y1=x1-1;
                counts.put(x,y1);
            }
            return  true;
        }
        return false;
    }
  
	

	@Override
	public String toString() {
		return "Myset [counts=" + counts + "]";
	}


	public static void main(String[] args) {
		Myset s = new Myset();
		//HashMap<String, Integer> newMap = (HashMap<String, Integer>) s.map;
		  s.add("Ati"); 
		  s.add("Tom");
          s.remove("Ati");
		  s.size();
		  s.contains("Ati");
       System.out.println(s.size());
		System.out.println(s);
	}
}
