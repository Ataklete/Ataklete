package shipping;

public interface SheppingFee {
	public double sheppingfee();

}
