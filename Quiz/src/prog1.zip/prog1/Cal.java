package prog1;

public interface Cal {

	public double computeArea();
	//public double computeAverageArea();
}
