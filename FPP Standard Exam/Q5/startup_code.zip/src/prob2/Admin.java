package prob2;

import java.util.List;

public class Admin {
	public static List/*<implement>*/ convertArray(Object[] studentArray) {
		/* implement */
		return null;
	}
	
	
	public static double computeAverageGpa(List/*<implement>*/ studentList) {
		/*implement */
		return 0.0;
	}
}
