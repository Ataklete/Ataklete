package prob2;

abstract public class Student {
	abstract public double computeGpa();
}
