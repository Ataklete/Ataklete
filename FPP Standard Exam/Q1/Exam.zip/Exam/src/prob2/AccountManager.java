package prob2;

import java.util.List;

public class AccountManager {
	//implement
	public static double computeAccountBalanceSum(List<Employee> emps) {
		return 0.0;
	}
}
