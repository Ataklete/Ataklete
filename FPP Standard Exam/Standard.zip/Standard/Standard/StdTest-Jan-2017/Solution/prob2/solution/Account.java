package prob2.solution;

public abstract class Account {
	abstract public double getBalance();
}
