package apr_std_2;

public interface Product {
   //implement
	public double getTotalValue();
}
