package apr_std_2;

/** A list of bicycle brands */
public enum Brand {
   SCHWINN, TREK, SURLY, BIANCHI;
}
