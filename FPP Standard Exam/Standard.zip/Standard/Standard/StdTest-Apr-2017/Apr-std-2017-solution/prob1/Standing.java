package lab2std;

public enum Standing {
	FRESHMAN, SOPHOMORE, JUNIOR, SENIOR;
}
