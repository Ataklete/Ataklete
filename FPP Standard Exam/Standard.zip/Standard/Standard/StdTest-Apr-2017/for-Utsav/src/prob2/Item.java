package prob2;

/** A list of accessory types in the store */
public enum Item {
	BICYCLE_PUMP, KICKSTAND, MIRROR, SECURITY_LOCK; 
}
