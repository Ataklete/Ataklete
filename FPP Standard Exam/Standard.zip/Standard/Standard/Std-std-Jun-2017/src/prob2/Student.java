package prob2;

abstract public class Student {
//implement
}
