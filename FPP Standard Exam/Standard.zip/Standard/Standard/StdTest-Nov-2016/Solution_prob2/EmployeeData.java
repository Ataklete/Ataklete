package prob2;

public interface EmployeeData {
	
	double getSalary();

}
