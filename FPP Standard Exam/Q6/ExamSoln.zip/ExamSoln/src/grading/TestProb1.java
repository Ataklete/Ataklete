package grading;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import junit.framework.TestCase;
import prob1.MyIntegerArrayList;

public class TestProb1 extends TestCase{
	
	public void testRemove() {
		Integer[] testData2 = {3,4};
		MyIntegerArrayList list = new MyIntegerArrayList(testData2);
		
		assertEquals("Expected 3 when calling remove(0)", new Integer(3), list.remove(0));
		assertEquals("After removing 3 from {3,4}, expected [4]", "[4]", list.toString());
		list.remove(0);
		assertEquals("After removing 3 from {3}, expected []", "[]", list.toString());
		Throwable t = null;
		try {
			list.remove(0); 
		} catch(Throwable e) {
			t = e;	
		}
		if(t == null || (t != null && t.getClass() != IndexOutOfBoundsException.class)) {
			fail("Expected IndexOutOfBoundsException");
		}
		
	}
	
	public void testSize() {
		Integer[] testData2 = {3,4};
		MyIntegerArrayList list = new MyIntegerArrayList(testData2);
		list.remove(0);
		assertEquals("Expected size is 1, but got " + list.size(), 1, list.size());
	}
	
	public void testNulls() {
		Integer[] testData2 = {3,4};
		MyIntegerArrayList list = new MyIntegerArrayList(testData2);
		list.remove(0);
		/* testing the test - inserting a null */
//		 Field[] fields = list.getClass().getDeclaredFields();
//		Field theArr = null;
//		for(Field f: fields) {
//			if(f.getName().equals("theArray")) {
//				theArr = f;
//				break;
//			}
//		}
//		try {
//			theArr.setAccessible(true);
//			Integer[] arr = (Integer[])theArr.get(list);
//			arr[0] = null;
//		} catch(Exception e) {
//			e.printStackTrace();
//		}
		/* end testing test */
		 
		
		assertFalse("After removing 4 from {3,4}, found null value in the list", containsNulls(list));
	}
	
	private boolean containsNulls(MyIntegerArrayList list) {
		Field[] fields = list.getClass().getDeclaredFields();
		Field theArr = null;
		for(Field f: fields) {
			if(f.getName().equals("theArray")) {
				theArr = f;
				
				break;
			}
		}
		if(theArr != null) {
			theArr.setAccessible(true);		
			Method[] methods = list.getClass().getDeclaredMethods();
			Method containsNulls = null;
			for(Method m: methods) {
				if(m.getName().equals("containsNulls")) {
					containsNulls = m;
					break;
				}
			}
			containsNulls.setAccessible(true);
			boolean result = false;
			Integer[] arr = null;
			try {
				arr = (Integer[])theArr.get(list);
			} catch(Exception e) {
				System.out.println("Problem reading array");
				e.printStackTrace();
			}
			try {
				//System.out.println((arr == null ? "null": Arrays.toString(arr)));
				Object[][] params = new Object[1][1];
				params[0] = arr;
				result = (Boolean)containsNulls.invoke(list, (Object[])params);
			} catch(Exception e) {
				System.out.println("Problem invoking method");
				System.out.println(e.getCause());
				e.printStackTrace();
			}
			return result;
		}
		return false;
	
	}
}
