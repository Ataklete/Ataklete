package prob2;

public abstract class Account {
	abstract public double getBalance();
}
