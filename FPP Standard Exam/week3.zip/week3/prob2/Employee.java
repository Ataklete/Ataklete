package week3.prob2;

public class Employee {

}
