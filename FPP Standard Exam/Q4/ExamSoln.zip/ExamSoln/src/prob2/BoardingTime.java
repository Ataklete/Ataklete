package prob2;

public interface BoardingTime {
	double computeBoardingTime();
}
