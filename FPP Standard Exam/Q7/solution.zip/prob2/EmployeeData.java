package practice5.prob2;

public interface EmployeeData {
	double getSalary();
}
